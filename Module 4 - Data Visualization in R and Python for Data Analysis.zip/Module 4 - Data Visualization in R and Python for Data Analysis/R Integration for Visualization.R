# BAN6420 Module 2 Assignment: Salary Function
# Voke Harrison Edafejimue
# Learner ID - 143304

#loading the libraries

library(tidyverse)
library(dplyr)
library(maps)
library(utils)
library(readr)
library(reticulate)

#Load Python Libraries


np <- import("numpy")
pd <- import("pandas")
plt <- import("matplotlib.pyplot")
sns <- import("seaborn")


#loading the data from current working directory


netflix_df <- read_csv("Netflix_shows_movies.csv")


#building a Python seaborn library countplot using countplot()


sns$countplot(r_to_py(netflix_df), y='rating', color='Green')

#display the plot
plt$show()


